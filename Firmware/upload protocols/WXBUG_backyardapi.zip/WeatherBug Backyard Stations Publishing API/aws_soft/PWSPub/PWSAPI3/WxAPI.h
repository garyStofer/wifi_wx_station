#if !defined(__WxAPI_)              // Sentry, use file only if it's not already included.
#define __WxAPI_

// Error codes

#define CROBOT_ERR_SUCCESS                0
#define CROBOT_ERR_INVALID_URL            1
#define CROBOT_ERR_INVALID_PARAMETER      2
#define CROBOT_ERR_CONNECTION_FAILED      3
#define CROBOT_ERR_TIMED_OUT              4
#define CROBOT_ERR_NOT_FOUND              5
#define CROBOT_ERR_NOT_AUTHORIZED         6
#define CROBOT_ERR_DISK_FILE_ERROR        7

// Base for disk/file error codes
#define    CROBOT_ERR_FILE              100


class WxAPI {
private:
    void PackFloat(unsigned char *lowchar, unsigned char *highchar, float inputFloat, int Precision=100);
    void GenerateKey(char *APIKey, char *Output);
    void UnPackFloat(unsigned char lowchar, unsigned char highchar, float *outputFloat, int Precision=100);
    bool CheckKey(char *Input);

	BOOL m_bReadFromCache, m_bWriteToCache;
	int m_nContext;
	CString m_sProxyLogonMethod, m_sProxyLogonUsername, m_sProxyLogonPassword;
	CString m_sLogonUsername, m_sLogonPassword;
	CString m_sUserAgent;
	
	// Header (httpHeader, httpHeaderFields)
	CString m_sHeader;
	
	// Number of header fields (httpHeaderFields)
	int m_nHeaderFields;
	
	// Header field names (httpHeaderFields)
	CString m_sHeadName[100];

	// Header field values (httpHeaderFields)
	CString m_sHeadValue[100];

	CString CreateStandardHeader();
	CString ErrorMessage(const int nError);
	CString EncodeTextBase64(const CString& sText);
	BOOL httpPost(const CString& sUrl, unsigned char *sData, int dataLength, CString& sResponse, int& nResult, CString& sErrMsg);
	int PackLiveWeatherData(unsigned char *sStr);
    int PackHistObWeatherData(unsigned char *sStr);
    int PackHistHiLoWeatherData(unsigned char *sStr);
    bool UnPackLiveWeatherData(unsigned char *sStr);
    bool UnPackHistObWeatherData(unsigned char *sStr);
    bool UnPackHistHiLoWeatherData(unsigned char *sStr);
    void CreateOb(unsigned char *sData);
    void CreateHilo(unsigned char *sData);
    bool UnpackOb(unsigned char *sData);
    bool UnpackHilo(unsigned char *sData);

public:		
	WxAPI();
    ~WxAPI();

	void SetStationParameters(int StationNum, char *StationID, char *Password);
	int TestPackandUnpack();

	CString PostLiveWeatherData();

	int  nStationNum;     //******Key input from user registration
    char sStationID[12];	//******Key input from user registration
	char sPassword[50];		//******Key input from user registration
    char Hour;
    char Minute;
    char Second;
    char Day;
    char Month;
    char Year;
	float indoortemp;  //Inside Temperature in degrees F. -50 to 150: 0.01 precision
	float outdoortemp;  //Outside Temperature in degrees F. -50 to 150: 0.01 precision
	float groundtemp;  //Ground/other Temperature in degrees F. -50 to 150: 0.01 precision
    float humidity;  //Relative Humidity 0 to 100%: 0.01 precision
	float pressure;  //Barometric Pressure ("Hg) -28.00 to 32.00: 0.01 precision
	float solar;  //Solar Reading 0 to 1800 W/m2: 0.1 precision
	float rain;  //Rainfall 0.00 to 100.00 inches: 0.01 precision
	float WindSpeed;  //Wind Speed 0 to 200.00 miles per hour: 0.01 precision
	float WindDir;  //Wind Direction 0 to 359.00 degrees: 0.01 precision
   	float RainRate;  //Rain Rate 0 to 20.00 inches per hour: 0.01 precision
	float AvgWindSpeed;  //Average Wind Speed in last 2 minutes: 0 to 200.00 miles per hour: 0.01 precision
	float AvgWindDir;  //Average 2 minute Wind Direction 0 to 359.00 degrees: 0.01 precision
	float OutTempRate;  //Outdoor Temperature Rate (deg F/hr): 0.01 precision
   	float PressureRate;  //Pressure Rate (in Hg/hr): 0.01 precision
   	float RHRate;  //Relative Humidity Rate (%/hr): 0.01 precision
   	float SolarRate;  //Solar Rate (W/m2/hr): 0.01 precision
   	float SoilMoisture;  //Soil Moisture %
   	float LeafWetness;  //Leaf Wetness %
   	float UV;  //UV .
   	float Visibility;  //Visibility nm.

   	float LastHourGust;  //Wind Gust in past hour (mph): 0-200 0.01 precision
   	float LastHourGustDir;  //Direction of Wind Gust in past hour (mph): 0-359 0.01 precision
    char HourGustTimeHr;  //The hour value of the hourly gust
	char HourGustTimeMinute; //The minute value of the hourly gust.

    char HiloMonth;   //This is the Month of the current high/low values 1-12
	char HiloDay;  //The current day of the high/low values 1-31
	int HiloYear; 
   	float HiOutTemp;  //Current High outdoor Temp Degrees F. -50 to 150, precision 0.01
    char HiOutTempHour;  //Time of occurrance (Hour) of the outdoor temp high.
	char HiOutTempMinute; //Time of occurrance (Minute) of the outdoor temp high. 
   	float LoOutTemp;  //Current Low outdoor Temp Degrees F. -50 to 150, precision 0.01
	char LoOutTempHour;
	char LoOutTempMinute;
   	float HiGroundTemp;  //Current High Ground Temp Degrees F. -50 to 150, precision 0.01
    char HiGroundTempHour;  //Time of occurrance (Hour) of the Ground temp high.
	char HiGroundTempMinute; //Time of occurrance (Minute) of the Ground temp high. 
   	float LoGroundTemp;  //Current Low Ground Temp Degrees F. -50 to 150, precision 0.01
	char LoGroundTempHour;  //Time of occurrance (Hour) of the Ground temp low.
	char LoGroundTempMinute; //Time of occurrance (Minute) of the Ground temp low. 
   	float HighHumidity;  //Current High Humidity %. 0 to 100, precision 0.01
    char HiHumidityHour;  //Time of occurrance (Hour) of the high Humidity.
	char HiHumidityMinute; //Time of occurrance (Minute) of the the high Humidity. 
   	float LowHumidity;  //Current Low Humidity %. 0 to 100, precision 0.01
	char LoHumidityHour;  //Time of occurrance (Hour) of the low humidity.
	char LoHumidityMinute; //Time of occurrance (Minute) of the low humidity. 
   	float HighPressure;  //Current High Barometer "Hg. 28 to 32, precision 0.01
    char HiPressureHour;  //Time of occurrance (Hour) of the high Pressure.
	char HiPressureMinute; //Time of occurrance (Minute) of the the high Pressure. 
   	float LowPressure;  //Current Low Pressure "Hg. 28 to 32, precision 0.01
	char LoPressureHour;  //Time of occurrance (Hour) of the low Pressure.
	char LoPressureMinute; //Time of occurrance (Minute) of the low Pressure. 
   	float Gust;  //Current Wind Gust for the day. MPH 0 to 200, precision 0.01
    char GustHour;  //Time of occurrance (Hour) of the Gust.
	char GustMinute; //Time of occurrance (Minute) of the the Gust. 
   	float GustDir;  //Direction of the wind gust. 0-359 precision 0.01
   	float MaxRainRate;  //Current Max Rain rate for the day. inches 0 to 100 , precision 0.01
	char MaxRainRateHour;
	char MaxRainRateMinute;
	float HighSolar;  //Current High Solar reading W/m2 0 to 1800, precision 0.01
    char HighSolarHour;  //Time of occurrance (Hour) of the high Pressure.
	char HighSolarMinute; //Time of occurrance (Minute) of the the high Pressure. 
   	float LowSolar;  //Current Low olar reading W/m2 0 to 1800, precision 0.01
	char LowSolarHour;  //Time of occurrance (Hour) of the low Solar.
	char LowSolarMinute; //Time of occurrance (Minute) of the low Solar. 
	float MonthlyRain;  //Rain so far this month 0.00 to 500.00 inches: 0.01 precision
	float YearlyRain;  //Rain so far this year 0.00 to 500.00 inches: 0.01 precision
};

#endif
