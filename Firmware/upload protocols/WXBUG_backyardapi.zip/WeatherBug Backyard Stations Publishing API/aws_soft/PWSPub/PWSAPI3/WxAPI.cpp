#include "stdafx.h"
#include "WxAPI.h"
#include <memory.h>
#include <stdio.h>
#include <string.h>
#include <afxinet.h>


WxAPI::WxAPI()
{
	m_bReadFromCache = false;
	m_bWriteToCache = false;
	m_nContext = 0;
	m_sLogonUsername = "";
	m_sLogonPassword = "";
	m_sProxyLogonMethod = "";
	m_sProxyLogonUsername = "";
	m_sProxyLogonPassword = "";
	m_sUserAgent = "Mozilla";
}


// Destructor

WxAPI::~WxAPI()
{
	m_sProxyLogonMethod.Empty();
	m_sProxyLogonUsername.Empty();
	m_sProxyLogonPassword.Empty();

}


void WxAPI::SetStationParameters(int StationNum, char *StationID, char *Password)
{
	nStationNum=StationNum;
	strncpy(sStationID, StationID, 10);   //Copy no more than 10 chars.
	strncpy(sPassword, Password, 10); //for password, we will use just the first 10 chars.
	sStationID[10]='\0';
	sPassword[10]='\0';
}

//This function assumes that all of the weather values have already been set and we are ready to post to the web site!
CString WxAPI::PostLiveWeatherData()
{
   unsigned char theData[500];
	//First PACK the data!
	memset(theData,0,sizeof(theData));
   int datasize=PackLiveWeatherData(theData);
	//Then Call HTTP POST!
   CString theURL;
   CString theResponse;
   CString theErrorMsg;
   int theResult;
   theURL = "http://data.backyard2.weatherbug.com/Data/livedata.aspx";
   httpPost(theURL, (unsigned char *)theData, datasize, theResponse, theResult, theErrorMsg);
   return theResponse;
}

int WxAPI::PackLiveWeatherData(unsigned char *sStr)
{
	unsigned char usTemp[200];
	memset(sStr,0,sizeof(200));

    //Header Info
    sStr[0] = 1; //Signifies this is a Live Weather Packet
    sStr[1]= 200; //Number of bytes in this packet.
    sStr[2]= 1;    //Version Number of this packet.
    sStr[3]= 121;     //fixed
    sStr[4]= 121;    //fixed

	//Station Number
	sStr[5]=(char)(nStationNum&0xFF);	    // low byte
	sStr[6]=(char)((nStationNum>>8)&0xFF);	// high byte	
    sStr[12] = 121;     //fixed

    int nCharsToCopy;
    if (strlen(sStationID)>9)
        nCharsToCopy=9;
    else
        nCharsToCopy=strlen(sStationID);    
    memcpy(&sStr[15], sStationID, nCharsToCopy); //Gotta be careful here that we only copy 9 chars at max!
	while (nCharsToCopy<=10) {
		sStr[15+nCharsToCopy]='\0';
		nCharsToCopy++;
	}

    //Password that the end user used to sign up for our site.
    if (strlen(sPassword)>9)
        nCharsToCopy=9;
    else
        nCharsToCopy=strlen(sPassword);    
    memcpy(&sStr[26], sPassword, nCharsToCopy); //Gotta be careful here that we only copy 9 chars at max!
	while (nCharsToCopy<=10) {   //Ensure the strings are appended with NULLS.
		sStr[26+nCharsToCopy]='\0';
		nCharsToCopy++;
	}

	memset(usTemp,0,sizeof (usTemp));
	CreateOb(usTemp);
	memcpy(&sStr[37],usTemp,65);
	
	memset(usTemp,0,sizeof (usTemp));	
	CreateHilo(usTemp);
	memcpy(&sStr[105],usTemp,80);

	return 190;
}

int WxAPI::PackHistObWeatherData(unsigned char *sStr)
{
	unsigned char usTemp[100];
	memset(sStr,0,sizeof(200));

    //Header Info
    sStr[0] = 10; //Signifies this is a HistOb Packet
    sStr[1]= 100; //Number of bytes in this packet.
    sStr[2]= 11;    //Version Number of this packet.
    sStr[3]= 121;     //fixed
    sStr[4]= 121;    //fixed

    //Station Number
	sStr[5]=(char)(nStationNum&0xFF);	    // low byte
	sStr[6]=(char)((nStationNum>>8)&0xFF);	// high byte	
    sStr[12] = 121;     //fixed

    int nCharsToCopy;
    if (strlen(sStationID)>9)
        nCharsToCopy=9;
    else
        nCharsToCopy=strlen(sStationID);    
    memcpy(&sStr[15], sStationID, nCharsToCopy); //Gotta be careful here that we only copy 9 chars at max!

    //Password that the end user used to sign up for our site.
    if (strlen(sPassword)>9)
        nCharsToCopy=9;
    else
        nCharsToCopy=strlen(sPassword);    
    memcpy(&sStr[26], sPassword, nCharsToCopy); //Gotta be careful here that we only copy 9 chars at max!
	while (nCharsToCopy<=10) {   //Ensure the strings are appended with NULLS.
		sStr[26+nCharsToCopy]='\0';
		nCharsToCopy++;
	}

	memset(usTemp,0,sizeof (usTemp));
	CreateOb(usTemp);
	memcpy(&sStr[37],usTemp,65);
	
	return 107;
}


int WxAPI::PackHistHiLoWeatherData(unsigned char *sStr)
{
	unsigned char usTemp[100];
	memset(sStr,0,sizeof(200));

    //Header Info
    sStr[0] = 20; //Signifies this is a HistHilo Packet
    sStr[1]= 150; //Number of bytes in this packet.
    sStr[2]= 21;    //Version Number of this packet.
    sStr[3]= 121;     //fixed
    sStr[4]= 121;    //fixed

    //Station Number
	sStr[5]=(char)(nStationNum&0xFF);	    // low byte
	sStr[6]=(char)((nStationNum>>8)&0xFF);	// high byte	
    sStr[12] = 121;     //fixed

    int nCharsToCopy;
    if (strlen(sStationID)>9)
        nCharsToCopy=9;
    else
        nCharsToCopy=strlen(sStationID);    
    memcpy(&sStr[15], sStationID, nCharsToCopy); //Gotta be careful here that we only copy 9 chars at max!

    //Password that the end user used to sign up for our site.
    if (strlen(sPassword)>9)
        nCharsToCopy=9;
    else
        nCharsToCopy=strlen(sPassword);    
    memcpy(&sStr[26], sPassword, nCharsToCopy); //Gotta be careful here that we only copy 9 chars at max!
	while (nCharsToCopy<=10) {   //Ensure the strings are appended with NULLS.
		sStr[26+nCharsToCopy]='\0';
		nCharsToCopy++;
	}

	memset(usTemp,0,sizeof (usTemp));	
	CreateHilo(usTemp);
	memcpy(&sStr[37],usTemp,80);
	
	return 122;
}




void WxAPI::CreateOb(unsigned char *sData)
{
    unsigned char lowint, highInt;

    sData[0]=Hour;  //0-23 Hour of observation
	sData[1]=Minute;     //0-59 Minute of Observation
	sData[2]=Second;   //0-59 Second of Observation
	sData[3]=Month;  //1-12 Month of Observation
	sData[4]=Day;   //1-31 Day of Observation
	sData[5]=Year;  //0-99 Year of Observation
	
	PackFloat(&lowint, &highInt, indoortemp);  //Inside Temperature in degrees F. -50 to 150: 0.01 precision
	sData[6]= (unsigned short) lowint;
	sData[7]= (unsigned short) highInt;
	
	PackFloat(&lowint, &highInt, outdoortemp);  //Outside Temperature in degrees F. -50 to 150: 0.01 precision
	sData[8]= (unsigned short) lowint;
	sData[9]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, groundtemp);  //Ground/other Temperature in degrees F. -50 to 150: 0.01 precision
	sData[10]= (unsigned short) lowint;
	sData[11]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, humidity);  //Relative Humidity 0 to 100%: 0.01 precision
	sData[12]= (unsigned short) lowint;
	sData[13]= (unsigned short) highInt;
	
	PackFloat(&lowint, &highInt, pressure);  //Barometric Pressure ("Hg) -28.00 to 32.00: 0.01 precision
	sData[14]= (unsigned short) lowint;
	sData[15]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, solar, 10);  //Solar Reading 0 to 1800 W/m2: 0.1 precision
	sData[16]= (unsigned short) lowint;
	sData[17]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, rain);  //Rainfall so far today 0.00 to 100.00 inches: 0.01 precision
	sData[18]= (unsigned short) lowint;
	sData[19]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, WindSpeed);  //Wind Speed 0 to 200.00 miles per hour: 0.01 precision
	sData[20]= (unsigned short) lowint;
	sData[21]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, WindDir);  //Wind Direction 0 to 359.00 degrees: 0.01 precision
	sData[22]= (unsigned short) lowint;
	sData[23]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, RainRate);  //Rain Rate 0 to 20.00 inches per hour: 0.01 precision (amount of rain in past 60 minutes)
	sData[24]= (unsigned short) lowint;
	sData[25]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, AvgWindSpeed);  //Average Wind Speed in last 2 minutes: 0 to 200.00 miles per hour: 0.01 precision
	sData[26]= (unsigned short) lowint;
	sData[27]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, AvgWindDir);  //Average 2 minute Wind Direction 0 to 359.00 degrees: 0.01 precision
	sData[28]= (unsigned short) lowint;
	sData[29]= (unsigned short) highInt;
	
	PackFloat(&lowint, &highInt, OutTempRate);  //Outdoor Temperature Rate (deg F/hr): 0.01 precision
	sData[30]= (unsigned short) lowint;
	sData[31]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, PressureRate);  //Pressure Rate (in Hg/hr): 0.01 precision
	sData[32]= (unsigned short) lowint;
	sData[33]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, RHRate);  //Relative Humidity Rate (%/hr): 0.01 precision
	sData[34]= (unsigned short) lowint;
	sData[35]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, SolarRate);  //Solar Rate (W/m2/hr): 0.01 precision
	sData[36]= (unsigned short) lowint;
	sData[37]= (unsigned short) highInt;

    //Add the information about hourly gust here.
   	PackFloat(&lowint, &highInt, LastHourGust);  //Wind Gust in past hour (mph): 0-200 0.01 precision
	sData[38]= (unsigned short) lowint;
	sData[39]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, LastHourGustDir);  //Direction of Wind Gust in past hour (mph): 0-359 0.01 precision
	sData[40]= (unsigned short) lowint;
	sData[41]= (unsigned short) highInt;

	sData[42] = HourGustTimeHr;
	sData[43] = HourGustTimeMinute;

   	PackFloat(&lowint, &highInt, SoilMoisture);  //%
	sData[44]= (unsigned short) lowint;
	sData[45]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, LeafWetness);  //%
	sData[46]= (unsigned short) lowint;
	sData[47]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, UV);  //--what is unit here?
	sData[48]= (unsigned short) lowint;
	sData[49]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, Visibility, 1);  //NM
	sData[50]= (unsigned short) lowint;
	sData[51]= (unsigned short) highInt;
}


void WxAPI::CreateHilo(unsigned char *sData)
 {
    unsigned char lowint, highInt;

    sData[0] = HiloMonth;   //This is the Month of the current high/low values 1-12
	sData[1] = HiloDay;  //The current day of the high/low values 1-31
	sData[2] = HiloYear&0xFF; 
	sData[3] = (HiloYear&0xFF00)>>8;  //The current Year of the high/low values (long year format, ie 2007)


   	PackFloat(&lowint, &highInt, HiOutTemp);  //Current High outdoor Temp Degrees F. -50 to 150, precision 0.01
	sData[4]= (unsigned short) lowint;
	sData[5]= (unsigned short) highInt;
    sData[6] = HiOutTempHour;  //Time of occurrance (Hour) of the outdoor temp high.
	sData[7] = HiOutTempMinute; //Time of occurrance (Minute) of the outdoor temp high. 
   	PackFloat(&lowint, &highInt, LoOutTemp);  //Current Low outdoor Temp Degrees F. -50 to 150, precision 0.01
	sData[8]= (unsigned short) lowint;
	sData[9]= (unsigned short) highInt;
	sData[10] = LoOutTempHour;
	sData[11] = LoOutTempMinute;
	

   	PackFloat(&lowint, &highInt, HiGroundTemp);  //Current High Ground Temp Degrees F. -50 to 150, precision 0.01
	sData[12]= (unsigned short) lowint;
	sData[13]= (unsigned short) highInt;
    sData[14] = HiGroundTempHour;  //Time of occurrance (Hour) of the Ground temp high.
	sData[15] = HiGroundTempMinute; //Time of occurrance (Minute) of the Ground temp high. 
   	PackFloat(&lowint, &highInt, LoGroundTemp);  //Current Low Ground Temp Degrees F. -50 to 150, precision 0.01
	sData[16]= (unsigned short) lowint;
	sData[17]= (unsigned short) highInt;
	sData[18] = LoGroundTempHour;  //Time of occurrance (Hour) of the Ground temp low.
	sData[19] = LoGroundTempMinute; //Time of occurrance (Minute) of the Ground temp low. 

   	PackFloat(&lowint, &highInt, HighHumidity);  //Current High Humidity %. 0 to 100, precision 0.01
	sData[20]= (unsigned short) lowint;
	sData[21]= (unsigned short) highInt;
    sData[22] = HiHumidityHour;  //Time of occurrance (Hour) of the high Humidity.
	sData[23] = HiHumidityMinute; //Time of occurrance (Minute) of the the high Humidity. 
   	PackFloat(&lowint, &highInt, LowHumidity);  //Current Low Humidity %. 0 to 100, precision 0.01
	sData[24]= (unsigned short) lowint;
	sData[25]= (unsigned short) highInt;
	sData[26] = LoHumidityHour;  //Time of occurrance (Hour) of the low humidity.
	sData[27] = LoHumidityMinute; //Time of occurrance (Minute) of the low humidity. 

   	PackFloat(&lowint, &highInt, HighPressure);  //Current High Barometer "Hg. 28 to 32, precision 0.01
	sData[28]= (unsigned short) lowint;
	sData[29]= (unsigned short) highInt;
    sData[30] = HiPressureHour;  //Time of occurrance (Hour) of the high Pressure.
	sData[31] = HiPressureMinute; //Time of occurrance (Minute) of the the high Pressure. 
   	PackFloat(&lowint, &highInt, LowPressure);  //Current Low Pressure "Hg. 28 to 32, precision 0.01
	sData[32]= (unsigned short) lowint;
	sData[33]= (unsigned short) highInt;
	sData[34] = LoPressureHour;  //Time of occurrance (Hour) of the low Pressure.
	sData[35] = LoPressureMinute; //Time of occurrance (Minute) of the low Pressure. 

   	PackFloat(&lowint, &highInt, Gust);  //Current Wind Gust for the day. MPH 0 to 200, precision 0.01
	sData[36]= (unsigned short) lowint;
	sData[37]= (unsigned short) highInt;
    sData[38] = GustHour;  //Time of occurrance (Hour) of the Gust.
	sData[39] = GustMinute; //Time of occurrance (Minute) of the the Gust. 
   	PackFloat(&lowint, &highInt, GustDir);  //Direction of the wind gust. 0-359 precision 0.01
	sData[40]= (unsigned short) lowint;
	sData[41]= (unsigned short) highInt;

   	PackFloat(&lowint, &highInt, MaxRainRate);  //Current Max Rain rate for the day. inches 0 to 100 , precision 0.01
	sData[42]= (unsigned short) lowint;
	sData[43]= (unsigned short) highInt;
	sData[44] = MaxRainRateHour;
	sData[45] = MaxRainRateMinute;
	
   	PackFloat(&lowint, &highInt, HighSolar, 10);  //Current High Solar reading W/m2 0 to 1800, precision 0.01
	sData[46]= (unsigned short) lowint;
	sData[47]= (unsigned short) highInt;
    sData[48] = HighSolarHour;  //Time of occurrance (Hour) of the high Pressure.
	sData[49] = HighSolarMinute; //Time of occurrance (Minute) of the the high Pressure. 
   	PackFloat(&lowint, &highInt, LowSolar, 10);  //Current Low olar reading W/m2 0 to 1800, precision 0.01
	sData[50]= (unsigned short) lowint;
	sData[51]= (unsigned short) highInt;
	sData[52] = LowSolarHour;  //Time of occurrance (Hour) of the low Solar.
	sData[53] = LowSolarMinute; //Time of occurrance (Minute) of the low Solar. 

	PackFloat(&lowint, &highInt, MonthlyRain);  //Rain so far this month 0.00 to 500.00 inches: 0.01 precision
	sData[54]= (unsigned short) lowint;
	sData[55]= (unsigned short) highInt;

	PackFloat(&lowint, &highInt, YearlyRain);  //Rain so far this year 0.00 to 500.00 inches: 0.01 precision
	sData[56]= (unsigned short) lowint;
	sData[57]= (unsigned short) highInt;
	
}


//This function will pack a float value into 2 bytes with a default precision of 0.01
void WxAPI::PackFloat(unsigned char *lowchar, unsigned char *highchar, float inputFloat, int Precision) {

    int iConvertInt;
    union item {
         short theInt;
         // In little-endian lo accesses the low 8-bits -
         // hi, the upper 8-bits
         struct { unsigned char lowchar; unsigned char highchar; } theChars;
    };
    item theItem;

	float fPrecision;
	fPrecision=Precision;
    iConvertInt = (int) (inputFloat*fPrecision); 
    theItem.theInt=iConvertInt;  
    *lowchar=theItem.theChars.lowchar;
    *highchar=theItem.theChars.highchar;
    return;
}


void WxAPI::GenerateKey(char *APIKey, char *Output) {
    
    Output[0]=APIKey[1];
    Output[1]=APIKey[2];
    Output[2]=APIKey[3];
    Output[3]=APIKey[4];
    Output[4]=APIKey[5];
    Output[5]=APIKey[6];
    Output[6]=APIKey[7];
    Output[7]=APIKey[8];
    Output[8]=APIKey[9];
    Output[9]=APIKey[10];
    return;
}

bool WxAPI::CheckKey(char *Input) {
    
    return true;
}


//**********************UNPACKING FUNCTIONS**********************
//This is the opposite of the PackLiveWeatherData function
bool WxAPI::UnPackLiveWeatherData(unsigned char *sStr)
{
	unsigned char usTemp[100];
	memset(sStr,0,sizeof(200));
	bool error;

    //Header Info
    if (sStr[0]!=1) error=true; //Signifies this is a HistOb Packet
    if (sStr[1]!=200) error=true; //Number of bytes in this packet.
    if (sStr[2]!=1) error=true;    //Version Number of this packet.
    if (sStr[3]!=121) error=true;     //fixed
    if (sStr[4]!=121) error=true;    //fixed

    //Station Number
	nStationNum=((sStr[6]<<8)&0xFF)|(sStr[5]&0xFF); //Rebuild the station number.
    if (sStr[12]!= 121) error=true;     //fixed

	memcpy(sStationID, &sStr[15], 10);
	sStationID[10]='\0';

    //API Code - I still need to expand upon this function to improve the securuty of the API.
    if (CheckKey((char *)&sStr[26])) error=true; //Unique key for every API Code.

	if (UnpackOb(&sStr[37])) error=true;
	if (UnpackHilo(&sStr[105])) error=true;

	return error;
}


//This is the opposite of the PackHistObWeather Data function
bool WxAPI::UnPackHistObWeatherData(unsigned char *sStr)
{
	unsigned char usTemp[100];
	memset(sStr,0,sizeof(200));
	bool error;

    //Header Info
    if (sStr[0]!=10) error=true; //Signifies this is a HistOb Packet
    if (sStr[1]!=100) error=true; //Number of bytes in this packet.
    if (sStr[2]!=11) error=true;    //Version Number of this packet.
    if (sStr[3]!=121) error=true;     //fixed
    if (sStr[4]!=121) error=true;    //fixed

    //Station Number
	nStationNum=((sStr[6]<<8)&0xFF)|(sStr[5]&0xFF); //Rebuild the station number.
    if (sStr[12]!=121) error=true;     //fixed

	memcpy(sStationID, &sStr[15], 10);
	sStationID[10]='\0';

    //API Code - I still need to expand upon this function to improve the securuty of the API.
    if (CheckKey((char *)&sStr[26])) error=true; //Unique key for every API Code.
	if (UnpackOb(&sStr[37])) error=true;

	return error;
}

//This is the opposite of the PackHistHiloWeather Data function
bool WxAPI::UnPackHistHiLoWeatherData(unsigned char *sStr)
{
	unsigned char usTemp[100];
	memset(sStr,0,sizeof(200));
	bool error=false;

    //Header Info
	if (sStr[0]!=20) error=true;  //Signifies this is a HistHilo Packet
    if (sStr[1]!=150) error=true; //Number of bytes in this packet.
    if (sStr[2]!=21) error=true;    //Version Number of this packet.
    if (sStr[3]!=121) error=true;     //fixed
    if (sStr[4]!=121) error=true;    //fixed

    //Station Number
	nStationNum=((sStr[6]<<8)&0xFF)|(sStr[5]&0xFF); //Rebuild the station number.
    if (sStr[12] = 121) error=true;     //fixed

	memcpy(sStationID, &sStr[15], 10);
	sStationID[10]='\0';

    //API Code - I still need to expand upon this function to improve the securuty of the API. Maybe this is a 10 character password we give the end user.
    if (CheckKey((char *)&sStr[26])) error=true; //Unique key for every API Code.

	if (UnpackHilo(&sStr[37])) error=true;

	return error;
}



//This funciton will unpack binary data and convert it to weather values.
//Returns true if there is an error, otherwise returns false.
//This function will also check the validity of the obs.
bool WxAPI::UnpackOb(unsigned char *sData)
{
    unsigned char lowint, highInt;

    Hour=sData[0];  //0-23 Hour of observation
	Minute=sData[1];     //0-59 Minute of Observation
	Second=sData[2];   //0-59 Second of Observation
	Month=sData[3];  //1-12 Month of Observation
	Day=sData[4];   //1-31 Day of Observation
	Year=sData[5];  //0-99 Year of Observation
	
	UnPackFloat(sData[6], sData[7], &indoortemp);  //Inside Temperature in degrees F. -50 to 150: 0.01 precision
	
	UnPackFloat(sData[8], sData[9], &outdoortemp);  //Outside Temperature in degrees F. -50 to 150: 0.01 precision

	UnPackFloat(sData[10], sData[11], &groundtemp);  //Ground/other Temperature in degrees F. -50 to 150: 0.01 precision

	UnPackFloat(sData[12], sData[13], &humidity);  //Relative Humidity 0 to 100%: 0.01 precision
	
	UnPackFloat(sData[14], sData[15], &pressure);  //Barometric Pressure ("Hg) -28.00 to 32.00: 0.01 precision

	UnPackFloat(sData[16], sData[17], &solar, 10);  //Solar Reading 0 to 1800 W/m2: 0.1 precision

	UnPackFloat(sData[18], sData[19], &rain);  //Rainfall so far today 0.00 to 100.00 inches: 0.01 precision

	UnPackFloat(sData[20], sData[21], &WindSpeed);  //Wind Speed 0 to 200.00 miles per hour: 0.01 precision

	UnPackFloat(sData[22], sData[23], &WindDir);  //Wind Direction 0 to 359.00 degrees: 0.01 precision

   	UnPackFloat(sData[24], sData[26], &RainRate);  //Rain Rate 0 to 20.00 inches per hour: 0.01 precision (amount of rain in past 60 minutes)

	UnPackFloat(sData[26], sData[27], &AvgWindSpeed);  //Average Wind Speed in last 2 minutes: 0 to 200.00 miles per hour: 0.01 precision

	UnPackFloat(sData[28], sData[29], &AvgWindDir);  //Average 2 minute Wind Direction 0 to 359.00 degrees: 0.01 precision
	
	UnPackFloat(sData[30], sData[31], &OutTempRate);  //Outdoor Temperature Rate (deg F/hr): 0.01 precision

   	UnPackFloat(sData[32], sData[33], &PressureRate);  //Pressure Rate (in Hg/hr): 0.01 precision

   	UnPackFloat(sData[34], sData[35], &RHRate);  //Relative Humidity Rate (%/hr): 0.01 precision

   	UnPackFloat(sData[36], sData[37], &SolarRate);  //Solar Rate (W/m2/hr): 0.01 precision

    //Add the information about hourly gust here.
   	UnPackFloat(sData[38], sData[39], &LastHourGust);  //Wind Gust in past hour (mph): 0-200 0.01 precision

   	UnPackFloat(sData[40], sData[41], &LastHourGustDir);  //Direction of Wind Gust in past hour (mph): 0-359 0.01 precision

	HourGustTimeHr=sData[42];
	HourGustTimeMinute=sData[43];

   	UnPackFloat(sData[44], sData[45], &SoilMoisture);  //%

   	UnPackFloat(sData[46], sData[47], &LeafWetness);  //%

   	UnPackFloat(sData[48], sData[49], &UV);  //--what is unit here?

   	UnPackFloat(sData[50], sData[51], &Visibility, 1);  //NM

	return true;
}


//This funciton will unpack binary data and convert it to weather values.
bool WxAPI::UnpackHilo(unsigned char *sData)
 {
    unsigned char lowint, highInt;

    HiloMonth=sData[0];   //This is the Month of the current high/low values 1-12
	HiloDay=sData[1];  //The current day of the high/low values 1-31
	HiloYear=sData[2]+256*sData[3]; 


   	UnPackFloat(sData[4], sData[5], &HiOutTemp);  //Current High outdoor Temp Degrees F. -50 to 150, precision 0.01
    HiOutTempHour=sData[6] ;  //Time of occurrance (Hour) of the outdoor temp high.
	HiOutTempMinute=sData[7]; //Time of occurrance (Minute) of the outdoor temp high. 
   	UnPackFloat(sData[8], sData[9], &LoOutTemp);  //Current Low outdoor Temp Degrees F. -50 to 150, precision 0.01
	LoOutTempHour=sData[10];
	LoOutTempMinute=sData[11];
	

   	UnPackFloat(sData[12], sData[13], &HiGroundTemp);  //Current High Ground Temp Degrees F. -50 to 150, precision 0.01
    HiGroundTempHour=sData[14];  //Time of occurrance (Hour) of the Ground temp high.
	HiGroundTempMinute=sData[15]; //Time of occurrance (Minute) of the Ground temp high. 
   	UnPackFloat(sData[16], sData[17], &LoGroundTemp);  //Current Low Ground Temp Degrees F. -50 to 150, precision 0.01
	LoGroundTempHour=sData[18];  //Time of occurrance (Hour) of the Ground temp low.
	LoGroundTempMinute=sData[19]; //Time of occurrance (Minute) of the Ground temp low. 

   	UnPackFloat(sData[20], sData[21], &HighHumidity);  //Current High Humidity %. 0 to 100, precision 0.01
    HiHumidityHour=sData[22];  //Time of occurrance (Hour) of the high Humidity.
	HiHumidityMinute=sData[23]; //Time of occurrance (Minute) of the the high Humidity. 
   	UnPackFloat(sData[24], sData[25], &LowHumidity);  //Current Low Humidity %. 0 to 100, precision 0.01
	LoHumidityHour=sData[26];  //Time of occurrance (Hour) of the low humidity.
	LoHumidityMinute=sData[27]; //Time of occurrance (Minute) of the low humidity. 

   	UnPackFloat(sData[28], sData[29], &HighPressure);  //Current High Barometer "Hg. 28 to 32, precision 0.01
    HiPressureHour=sData[30];  //Time of occurrance (Hour) of the high Pressure.
	HiPressureMinute=sData[31]; //Time of occurrance (Minute) of the the high Pressure. 
   	UnPackFloat(sData[32], sData[33], &LowPressure);  //Current Low Pressure "Hg. 28 to 32, precision 0.01
	LoPressureHour=sData[34];  //Time of occurrance (Hour) of the low Pressure.
	LoPressureMinute=sData[35]; //Time of occurrance (Minute) of the low Pressure. 

   	UnPackFloat(sData[36], sData[37], &Gust);  //Current Wind Gust for the day. MPH 0 to 200, precision 0.01
    GustHour=sData[38];  //Time of occurrance (Hour) of the Gust.
	GustMinute=sData[39]; //Time of occurrance (Minute) of the the Gust. 
   	UnPackFloat(sData[40], sData[41], &GustDir);  //Direction of the wind gust. 0-359 precision 0.01

   	UnPackFloat(sData[42], sData[43], &MaxRainRate);  //Current Max Rain rate for the day. inches 0 to 100 , precision 0.01
	MaxRainRateHour=sData[44];
	MaxRainRateMinute=sData[45];
	
   	UnPackFloat(sData[46], sData[47], &HighSolar, 10);  //Current High Solar reading W/m2 0 to 1800, precision 0.01
    HighSolarHour=sData[48];  //Time of occurrance (Hour) of the high Pressure.
	HighSolarMinute=sData[49]; //Time of occurrance (Minute) of the the high Pressure. 
   	UnPackFloat(sData[50], sData[51], &LowSolar, 10);  //Current Low olar reading W/m2 0 to 1800, precision 0.01
	LowSolarHour=sData[52];  //Time of occurrance (Hour) of the low Solar.
	LowSolarMinute=sData[53]; //Time of occurrance (Minute) of the low Solar. 

	UnPackFloat(sData[54], sData[55], &MonthlyRain);  //Rain so far this month 0.00 to 500.00 inches: 0.01 precision

	UnPackFloat(sData[56], sData[57], &YearlyRain);  //Rain so far this year 0.00 to 500.00 inches: 0.01 precision
	return true;
	
}


//This function will UnPack a float value into from 2 bytes of data
void WxAPI::UnPackFloat(unsigned char lowchar, unsigned char highchar, float *outputFloat, int Precision) {

    int iConvertInt;
    union item {
         short theInt;
         // In little-endian lo accesses the low 8-bits -
         // hi, the upper 8-bits
         struct { unsigned char lowchar; unsigned char highchar; } theChars;
    };
    item theItem;

    theItem.theChars.lowchar=lowchar;
    theItem.theChars.highchar=highchar;

	*outputFloat=theItem.theInt*1.0/Precision;
    return;
}



// --------------------------------------------------------------
// ************** public
// *            *
// *  httpPost  *
// *            *
// **************
// Function: Submits a URL and form data/parameters using the POST
//           method. Retrieves a response returns it in CString form.
//
// Inputs:	sURL              - The URL to access
//								 (example: "www.mysite.com")
//			sData			  - The parameters (or "form data")
//								 to submit
//
// Outputs:	<function_result> - True if data was successfully
//								 retrieved, false otherwise
//			sResponse         - The HTML retrieved
//			nResult           - Completion code. 0 = success,
//								 n = error (defined in CRobot.h)
//			sErrMsg           - The error message, if nResult != 0

BOOL WxAPI::httpPost(const CString& sUrl,
							  unsigned char *sData, int dataLength,
							  CString& sResponse,
							  int& nResult, CString& sErrMsg)
{
	CInternetSession* pSession;
	CHttpConnection* pConnection;
	CHttpFile* pHttpFile;
	int nRead;
	LPSTR pBuffer = NULL;
	CString sResult;
	CString sWorkingUrl;
	CString sHeaders = CString("");
	CString sMsg;
	sErrMsg = CString("");
	DWORD dwHttpStatus;
	nResult = CROBOT_ERR_SUCCESS;
	unsigned char sTemp[1024];

	try 
	{
		pSession = NULL;
		pConnection = NULL;
		pHttpFile = NULL;
		nRead = 0;
		pBuffer = new char[1024];
		sResult = "";
		sWorkingUrl = sUrl;
		sHeaders = CString("Content-Type: "
					  "application/x-www-form-urlencoded\r\n")
				   + CreateStandardHeader();

		/* Trim URL and add http:// if it contains no 
		   protocol identifier */
		
		sWorkingUrl.TrimLeft();
		sWorkingUrl.TrimRight();
		if (sWorkingUrl.Find(CString(":")) == -1) 
		{
			if (sWorkingUrl.Left(1) == "/")
				sWorkingUrl = CString("http:") + sWorkingUrl;
			else
				sWorkingUrl = CString("http://") + sWorkingUrl;
		} // End if

		/* Check the URL - must be valid and of the 'http:'
		   service type */
		DWORD dwServiceType;
		CString sServer, sObject;
		unsigned short nPort;
		if (AfxParseURL(sWorkingUrl,
						dwServiceType,
						sServer,
						sObject,
						nPort))
		{
			// URL is valid. Now check service type.
			if (dwServiceType == AFX_INET_SERVICE_HTTP) 
			{
				// Service type is valid (HTTP). Now make connection.
				pSession = new CInternetSession(
										m_sUserAgent,
										1,
										INTERNET_OPEN_TYPE_PRECONFIG);
				pConnection = pSession->GetHttpConnection(sServer,
														  nPort,
														  NULL,
														  NULL);

				pHttpFile = pConnection->OpenRequest(
										CHttpConnection::HTTP_VERB_POST,
										sObject,
										NULL,
										1,
										NULL,
										NULL,
										INTERNET_FLAG_RELOAD | INTERNET_FLAG_DONT_CACHE | INTERNET_FLAG_NO_AUTO_REDIRECT);
				memcpy (sTemp, sData, dataLength);
				pHttpFile->SendRequest(sHeaders, sTemp, dataLength);  //Length of sData...sHeaders, sTemp, 100
				if (pHttpFile) /* SendRequest worked */
				{
					// Check the http return code
					if (!pHttpFile->QueryInfoStatusCode(dwHttpStatus))
						dwHttpStatus = 200;

					if (dwHttpStatus >= 400)
					{
						switch(dwHttpStatus)
						{
						case 404:
							nResult = CROBOT_ERR_NOT_FOUND;
							break;
						case 403:
						case 407:
							nResult = CROBOT_ERR_NOT_AUTHORIZED;
							break;
						default:
							nResult = CROBOT_ERR_CONNECTION_FAILED;
							break;
						} // End switch
					} // End if dwHttpStatus
					else /* No error - read response data */
					{
						nResult = CROBOT_ERR_SUCCESS;
						do 
						{
							nRead = pHttpFile->Read(pBuffer, 1023);
							if (nRead != 0) 
							{
								pBuffer[nRead] = 0;
								sResult += pBuffer;
							} // End if
						} while (nRead != 0);
						sResponse = sResult;
					} // End else
				} // End if pHttpFile
				else /* SendRequest failed */
				{
					nResult = CROBOT_ERR_CONNECTION_FAILED;
				} // End else
			} // End if
			else
				// Wrong service
				nResult = CROBOT_ERR_INVALID_URL;
		} // End if
		else
			// Invalid URL
			nResult = CROBOT_ERR_INVALID_URL;
	} // End try

	catch (CInternetException* e) 
	{
		e->Delete();
		sResponse = sResult;
		
		// Exception occurred
		nResult = CROBOT_ERR_CONNECTION_FAILED;
	} // End catch
	catch (...) 
	{
		sResponse = sResult;
		
		// Exception occurred
		nResult = CROBOT_ERR_CONNECTION_FAILED;
	} // End catch

// Clean up and exit function

	if (pBuffer != NULL)
	{
		delete pBuffer;
		pBuffer = NULL;
	} // End if
	
	if (pHttpFile != NULL) 
	{
		pHttpFile->Close();
		delete pHttpFile; 
	} // End if

	if (pConnection != NULL) 
	{
		pConnection->Close();
		delete pConnection; 
	} // End if

	if (pSession != NULL) 
	{
		pSession->Close();
		delete pSession; 
	} // End if
	
	sErrMsg = ErrorMessage(nResult);
	if (nResult == CROBOT_ERR_SUCCESS)
		return true;
	else
		return false;
}



// ---------------------------------------------------------------
// ************************** private
// *                        *
// *  CreateStandardHeader  *
// *                        *
// **************************
// Function: Return a standard header to use with OpenURL calls.
//           If a call has been made to set proxy logon information,
//           the authentication string is included in the header
//			 that is returned.
//
// This is a private function called by various public functions.

CString WxAPI::CreateStandardHeader()
{
	CString sHeader;

	sHeader = "Accept: */*\r\n";

	if (m_sProxyLogonMethod=="basic" && m_sProxyLogonUsername!="")
	{
		sHeader += CString("Proxy-authorization: Basic ")
				   + EncodeTextBase64(m_sProxyLogonUsername 
									  + CString(":")
									  + m_sProxyLogonPassword)
				   + CString("\r\n");
	} // End if

	if (m_sLogonUsername != "") 
	{
/*		sHeader += "Authorization: "
				   + m_sLogonUsername
				   + ":"
				   + m_sLogonPassword
				   + "\r\n";
*/
		sHeader += CString("Authorization: Basic ")
				   + EncodeTextBase64(m_sLogonUsername
				                      + CString(":")
									  + m_sLogonPassword)
				   + CString("\r\n");
	} // End if

	sHeader += "\r\n";
	return sHeader;
}


// ****************** private
// *                *
// *  ErrorMessage  *
// *                *
// ******************
// Function: Returns a textual message describing a CRobot
//           error code.

CString WxAPI::ErrorMessage(const int nError)
{
	CString sErrMsg = CString("");

	switch (nError) 
	{
	case CROBOT_ERR_SUCCESS:
		sErrMsg = "Successful";
		break;
	case CROBOT_ERR_INVALID_URL:
		sErrMsg = "Invalid URL";
		break;
	case CROBOT_ERR_INVALID_PARAMETER:
		sErrMsg = "Invalid parameter";
		break;
	case CROBOT_ERR_CONNECTION_FAILED:
		sErrMsg = "Connection failed";
		break;
	case CROBOT_ERR_TIMED_OUT:
		sErrMsg = "Timed out";
		break;
	case CROBOT_ERR_NOT_FOUND:
		sErrMsg = "Not found";
		break;
	case CROBOT_ERR_NOT_AUTHORIZED:
		sErrMsg = "Not authorized";
		break;
	case CROBOT_ERR_DISK_FILE_ERROR:
		sErrMsg = "Disk/file error";
		break;
	default:
		sErrMsg.Format(CString("CRobotInternet error %d"), nError);
		break;
	} // End switch
	return sErrMsg;
}

////////////////////////////////////////////////////////////////////
//
// Support functions


// ********************** private
// *                    *
// *  EncodeTextBase64  *
// *                    *
// **********************
// Function: Returns the Base64-encoded version of a text string.

CString WxAPI::EncodeTextBase64(const CString& sText)
{
	unsigned char cChar[255];
	int nIndex1, nIndex2, nIndex3, nIndex4;
	int nChars;
	CString sBase64 = CString("");
	char cTable[64 + 1];
	CString sTemp;

	cTable[0] = 'A';
	cTable[1] = 'B';
	cTable[2] = 'C';
	cTable[3] = 'D';
	cTable[4] = 'E';
	cTable[5] = 'F';
	cTable[6] = 'G';
	cTable[7] = 'H';
	cTable[8] = 'I';
	cTable[9] = 'J';
	cTable[10] = 'K';
	cTable[11] = 'L';
	cTable[12] = 'M';
	cTable[13] = 'N';
	cTable[14] = 'O';
	cTable[15] = 'P';

	cTable[16] = 'Q';
	cTable[17] = 'R';
	cTable[18] = 'S';
	cTable[19] = 'T';
	cTable[20] = 'U';
	cTable[21] = 'V';
	cTable[22] = 'W';
	cTable[23] = 'X';
	cTable[24] = 'Y';
	cTable[25] = 'Z';
	cTable[26] = 'a';
	cTable[27] = 'b';
	cTable[28] = 'c';
	cTable[29] = 'd';
	cTable[30] = 'e';
	cTable[31] = 'f';

	cTable[32] = 'g';
	cTable[33] = 'h';
	cTable[34] = 'i';
	cTable[35] = 'j';
	cTable[36] = 'k';
	cTable[37] = 'l';
	cTable[38] = 'm';
	cTable[39] = 'n';
	cTable[40] = 'o';
	cTable[41] = 'p';
	cTable[42] = 'q';
	cTable[43] = 'r';
	cTable[44] = 's';
	cTable[45] = 't';
	cTable[46] = 'u';
	cTable[47] = 'v';

	cTable[48] = 'w';
	cTable[49] = 'x';
	cTable[50] = 'y';
	cTable[51] = 'z';
	cTable[52] = '0';
	cTable[53] = '1';
	cTable[54] = '2';
	cTable[55] = '3';
	cTable[56] = '4';
	cTable[57] = '5';
	cTable[58] = '6';
	cTable[59] = '7';
	cTable[60] = '8';
	cTable[61] = '9';
	cTable[62] = '+';
	cTable[63] = '/';

	cTable[64] = '=';

	nChars = sText.GetLength();
	for (int nPos = 0; nPos < nChars; nPos++) 
	{
		cChar[nPos] = sText.GetAt(nPos);
	} // End for

	//   cChar[nPos]    cChar[nPos+1]   cChar[nPos+2]
	//        |               |               |
	// -------+------- -------+------- -------+-------
	// 7 6 5 4 3 2 1 0 7 6 5 4 3 2 1 0 7 6 5 4 3 2 1 0
	// | | | | | | | | | | | | | | | | | | | | | | | |
	// x x x x x x x x x x x x x x x x x x x x x x x x
	// | | | | | | | | | | | | | | | | | | | | | | | |
	// 5 4 3 2 1 0 5 4 3 2 1 0 5 4 3 2 1 0 5 4 3 2 1 0
	// -----+----- -----+----- -----+----- -----+-----
	//      |           |           |           |
	//   nIndex1     nIndex2     nIndex3     nIndex4
	//

	for (int nPos = 0; nPos < nChars; nPos += 3)
	{
		if (nPos + 1 >= nChars) cChar[nPos + 1] = '0';
		if (nPos + 2 >= nChars) cChar[nPos + 2] = '0';
		nIndex4 = ( cChar[nPos + 2] & 0x3F ) & 0x3F;
		nIndex3 = ( ((cChar[nPos + 1] & 0x0F) << 2) 
					| ((cChar[nPos + 2] & 0xC0) >> 6) ) & 0x3F;
		nIndex2 = ( ((cChar[nPos] & 3) << 4) 
					| ((cChar[nPos + 1] & 0xF0) >> 4) ) & 0x3F;
		nIndex1 = ( (cChar[nPos] & 0xFC) >> 2 ) & 0x3F;
		if (nPos + 1 >= nChars)
		{
			nIndex3 = 64;
			nIndex4 = 64;
		} // end if
		if (nPos + 2 >= nChars)
		{
			nIndex4 = 64;
		} // end if
		sTemp.Format(CString("%c%c%c%c"),
					 cTable[nIndex1],
					 cTable[nIndex2],
					 cTable[nIndex3],
					 cTable[nIndex4]);
		sBase64 += sTemp;
	} // End for

	return sBase64;
}

//Just a test function to ensure that we get back out what we put in within error since we are packing a float in an int.
int WxAPI::TestPackandUnpack()
{

	CTime curTime = CTime::GetCurrentTime();

	int myHour=curTime.GetHour();
	int myMinute=curTime.GetMinute();
    int mySecond=curTime.GetSecond();
    int myDay=curTime.GetDay();
    int myMonth=curTime.GetMonth();
    int myYear=curTime.GetYear()-2000;

	float myindoortemp=73.5;  
	float myoutdoortemp=73.2;  //Outside Temperature in degrees F. -50 to 150: 0.01 precision
	float mygroundtemp=73.1;  //Ground/other Temperature in degrees F. -50 to 150: 0.01 precision
    float myhumidity=50.3;  //Relative Humidity 0 to 100%: 0.01 precision
	float mypressure=30.21;  //Barometric Pressure ("Hg) -28.00 to 32.00: 0.01 precision
	float mysolar=50.56;  //Solar Reading 0 to 1800 W/m2: 0.1 precision
	float myrain=2.13;  //Rainfall 0.00 to 100.00 inches: 0.01 precision
	float myWindSpeed=22.1;  //Wind Speed 0 to 200.00 miles per hour: 0.01 precision
	float myWindDir=100;  //Wind Direction 0 to 359.00 degrees: 0.01 precision
   	float myRainRate=0.60;  //Rain Rate 0 to 20.00 inches per hour: 0.01 precision
	float myAvgWindSpeed=20.1;  //Average Wind Speed in last 2 minutes: 0 to 200.00 miles per hour: 0.01 precision
	float myAvgWindDir=45.5;  //Average 2 minute Wind Direction 0 to 359.00 degrees: 0.01 precision
	float myOutTempRate=0;  //Outdoor Temperature Rate (deg F/hr): 0.01 precision
   	float myPressureRate=0;  //Pressure Rate (in Hg/hr): 0.01 precision
   	float myRHRate=0;  //Relative Humidity Rate (%/hr): 0.01 precision
   	float mySolarRate=0;  //Solar Rate (W/m2/hr): 0.01 precision
   	float mySoilMoisture=10;  //Soil Moisture %
   	float myLeafWetness=20;  //Leaf Wetness %
   	float myUV=55;  //UV .
   	float myVisibility=10;  //Visibility nm.

   	float myLastHourGust=30.33;  //Wind Gust in past hour (mph): 0-200 0.01 precision
   	float myLastHourGustDir=49.08;  //Direction of Wind Gust in past hour (mph): 0-359 0.01 precision
    char myHourGustTimeHr=11;  //The hour value of the hourly gust
	char myHourGustTimeMinute=11; //The minute value of the hourly gust.

	char myHiloMonth=curTime.GetMonth();   //This is the Month of the current high/low values 1-12
	char myHiloDay=curTime.GetDay();  //The current day of the high/low values 1-31
	int myHiloYear=curTime.GetYear(); 
   	float myHiOutTemp=90.33;  //Current High outdoor Temp Degrees F. -50 to 150, precision 0.01
    char myHiOutTempHour=17;  //Time of occurrance (Hour) of the outdoor temp high.
	char myHiOutTempMinute=33; //Time of occurrance (Minute) of the outdoor temp high. 
   	float myLoOutTemp=33.33;  //Current Low outdoor Temp Degrees F. -50 to 150, precision 0.01
	char myLoOutTempHour=6;
	char myLoOutTempMinute=23;
   	float myHiGroundTemp=56.55;  //Current High Ground Temp Degrees F. -50 to 150, precision 0.01
    char myHiGroundTempHour=11;  //Time of occurrance (Hour) of the Ground temp high.
	char myHiGroundTempMinute=11; //Time of occurrance (Minute) of the Ground temp high. 
   	float myLoGroundTemp=55.55;  //Current Low Ground Temp Degrees F. -50 to 150, precision 0.01
	char myLoGroundTempHour=20;  //Time of occurrance (Hour) of the Ground temp low.
	char myLoGroundTempMinute=11; //Time of occurrance (Minute) of the Ground temp low. 
   	float myHighHumidity=100.0;  //Current High Humidity %. 0 to 100, precision 0.01
    char myHiHumidityHour=11;  //Time of occurrance (Hour) of the high Humidity.
	char myHiHumidityMinute=11; //Time of occurrance (Minute) of the the high Humidity. 
   	float myLowHumidity=23;  //Current Low Humidity %. 0 to 100, precision 0.01
	char myLoHumidityHour=11;  //Time of occurrance (Hour) of the low humidity.
	char myLoHumidityMinute=11; //Time of occurrance (Minute) of the low humidity. 
   	float myHighPressure=30.33;  //Current High Barometer "Hg. 28 to 32, precision 0.01
    char myHiPressureHour=11;  //Time of occurrance (Hour) of the high Pressure.
	char myHiPressureMinute=11; //Time of occurrance (Minute) of the the high Pressure. 
   	float myLowPressure=28.77;  //Current Low Pressure "Hg. 28 to 32, precision 0.01
	char myLoPressureHour=11;  //Time of occurrance (Hour) of the low Pressure.
	char myLoPressureMinute=11; //Time of occurrance (Minute) of the low Pressure. 
   	float myGust=30.44;  //Current Wind Gust for the day. MPH 0 to 200, precision 0.01
    char myGustHour=11;  //Time of occurrance (Hour) of the Gust.
	char myGustMinute=11; //Time of occurrance (Minute) of the the Gust. 
   	float myGustDir=234;  //Direction of the wind gust. 0-359 precision 0.01
   	float myMaxRainRate=2.14;  //Current Max Rain rate for the day. inches 0 to 100 , precision 0.01
	char myMaxRainRateHour=11;
	char myMaxRainRateMinute=11;
	float myHighSolar=99.3;  //Current High Solar reading W/m2 0 to 1800, precision 0.01
    char myHighSolarHour=12;  //Time of occurrance (Hour) of the high Pressure.
	char myHighSolarMinute=12; //Time of occurrance (Minute) of the the high Pressure. 
   	float myLowSolar=0;  //Current Low olar reading W/m2 0 to 1800, precision 0.01
	char myLowSolarHour=23;  //Time of occurrance (Hour) of the low Solar.
	char myLowSolarMinute=59; //Time of occurrance (Minute) of the low Solar. 
	float myMonthlyRain=4.17;  //Rain so far this month 0.00 to 500.00 inches: 0.01 precision
	float myYearlyRain=20.73;  //Rain so far this year 0.00 to 500.00 inches: 0.01 precision
    unsigned char theData[500];
	int theResult=0;

	memset(theData,0,sizeof(theData));
	CreateOb(theData);
	UnpackOb(theData);

	memset(theData,0,sizeof(theData));
	CreateHilo(theData);
	UnpackHilo(theData);


	if (outdoortemp-myoutdoortemp>0.01)
		theResult=theResult+1;

    if (Hour!=myHour) theResult=theResult+1;
    if (Minute!=myMinute) theResult=theResult+1;
    if (Second!=mySecond) theResult=theResult+1;
    if (Day!=myDay) theResult=theResult+1;
    if (Month!=myMonth) theResult=theResult+1;
    if (Year!=myYear) theResult=theResult+1; ///WRONG!!!
	if (indoortemp-myindoortemp>0.01)  theResult=theResult+1;
	if (outdoortemp-myoutdoortemp>0.01)  theResult=theResult+1;
	if (groundtemp-mygroundtemp>0.01)  theResult=theResult+1;
    if (humidity-myhumidity>0.01)  theResult=theResult+1;
	if (pressure-mypressure>0.01)  theResult=theResult+1;
	if (solar-mysolar>0.01)  theResult=theResult+1;
	if (rain-myrain>0.01)  theResult=theResult+1;
	if (WindSpeed-myWindSpeed>0.01)    theResult=theResult+1;
	if (WindDir-myWindDir>0.01)    theResult=theResult+1;
   	if (RainRate-myRainRate>0.01)    theResult=theResult+1;
	if (AvgWindSpeed-myAvgWindSpeed>0.01)    theResult=theResult+1;
	if (AvgWindDir-myAvgWindDir>0.01)    theResult=theResult+1;
	if (OutTempRate-myOutTempRate>0.01)    theResult=theResult+1;
   	if (PressureRate-myPressureRate>0.01)    theResult=theResult+1;
   	if (RHRate-myRHRate>0.01)    theResult=theResult+1;
   	if (SolarRate-mySolarRate>0.01)    theResult=theResult+1;
   	if (SoilMoisture-mySoilMoisture>0.01)    theResult=theResult+1;
   	if (LeafWetness-myLeafWetness>0.01)    theResult=theResult+1;
   	if (UV-myUV>0.01)    theResult=theResult+1;
   	if (Visibility-myVisibility>0.01)    theResult=theResult+1;
   	if (LastHourGust-myLastHourGust>0.01)    theResult=theResult+1;
   	if (LastHourGustDir-myLastHourGustDir>0.01)    theResult=theResult+1;
    if (HourGustTimeHr!=myHourGustTimeHr)    theResult=theResult+1;
	if (HourGustTimeMinute!=myHourGustTimeMinute)    theResult=theResult+1;

    if (HiloMonth!=myHiloMonth)    theResult=theResult+1;   //This is the Month of the current high/low values 1-12
	if (HiloDay!=myHiloDay)    theResult=theResult+1;  //The current day of the high/low values 1-31
	if (HiloYear!=myHiloYear)    theResult=theResult+1;
   	if (HiOutTemp-myHiOutTemp)    theResult=theResult+1;
    if (HiOutTempHour!=myHiOutTempHour)    theResult=theResult+1;
	if (HiOutTempMinute!=myHiOutTempMinute)    theResult=theResult+1;
   	if (LoOutTemp-myLoOutTemp>0.01)    theResult=theResult+1;
	if (LoOutTempHour!=myLoOutTempHour)    theResult=theResult+1;
	if (LoOutTempMinute!=myLoOutTempMinute)    theResult=theResult+1;
   	if (HiGroundTemp-myHiGroundTemp>0.01)    theResult=theResult+1;
    if (HiGroundTempHour!=myHiGroundTempHour)    theResult=theResult+1;
	if (HiGroundTempMinute!=myHiGroundTempMinute)    theResult=theResult+1;
   	if (LoGroundTemp-myLoGroundTemp>0.01)    theResult=theResult+1;
	if (LoGroundTempHour!=myLoGroundTempHour)    theResult=theResult+1;
	if (LoGroundTempMinute!=myLoGroundTempMinute)    theResult=theResult+1;
   	if (HighHumidity-myHighHumidity>0.01)    theResult=theResult+1;
    if (HiHumidityHour!=myHiHumidityHour)    theResult=theResult+1;
	if (HiHumidityMinute!=myHiHumidityMinute)    theResult=theResult+1;
   	if (LowHumidity-myLowHumidity>0.01)    theResult=theResult+1;
	if (LoHumidityHour!=myLoHumidityHour)    theResult=theResult+1;
	if (LoHumidityMinute!=myLoHumidityMinute)    theResult=theResult+1;
   	if (HighPressure-myHighPressure>0.01)    theResult=theResult+1;
    if (HiPressureHour!=myHiPressureHour)    theResult=theResult+1;
	if (HiPressureMinute!=myHiPressureMinute)    theResult=theResult+1;
   	if (LowPressure-myLowPressure>0.01)    theResult=theResult+1;
	if (LoPressureHour!=myLoPressureHour)    theResult=theResult+1;
	if (LoPressureMinute!=myLoPressureMinute)    theResult=theResult+1;
   	if (Gust-myGust>0.01)    theResult=theResult+1;
    if (GustHour!=myGustHour)    theResult=theResult+1;
	if (GustMinute!=myGustMinute)    theResult=theResult+1;
   	if (GustDir-myGustDir>0.01)    theResult=theResult+1;
   	if (MaxRainRate-myMaxRainRate>0.01)    theResult=theResult+1;
	if (MaxRainRateHour!=myMaxRainRateHour)    theResult=theResult+1;
	if (MaxRainRateMinute!=myMaxRainRateMinute)    theResult=theResult+1;
	if (HighSolar-myHighSolar>0.01)    theResult=theResult+1;
    if (HighSolarHour!=myHighSolarHour)    theResult=theResult+1;
	if (HighSolarMinute!=myHighSolarMinute)    theResult=theResult+1;
   	if (LowSolar-myLowSolar>0.01)    theResult=theResult+1;
	if (LowSolarHour!=myLowSolarHour)    theResult=theResult+1;
	if (LowSolarMinute!=myLowSolarMinute)    theResult=theResult+1;
	if (MonthlyRain-myMonthlyRain>0.01)    theResult=theResult+1;
	if (YearlyRain-myYearlyRain>0.01)    theResult=theResult+1;

	return theResult;

}