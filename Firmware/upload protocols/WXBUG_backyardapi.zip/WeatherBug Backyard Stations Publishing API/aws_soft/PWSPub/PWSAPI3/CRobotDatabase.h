////////////////////////////////////////////////////////////////////
//
// CRobotDatabase.h - CRobotDatabase class declarations
//
// Source: "Programming Bots, Spiders, and Intelligent Agents
//          in Microsoft Visual C++"
//
// Copyright (c) 1999, David Pallmann. All rights reserved.

#define	MAX_FIELDS	500

#include <sql.h>
#include <sqlext.h>

class CRobotDatabase
{
public:
	CRobotDatabase();
	~CRobotDatabase();
	BOOL Open(const CString& sDSN,
			  const CString& sTable,
			  const CString& sUserId,
			  const CString& sPassword);
	void Close();
	BOOL Execute(const CString& sSQL);
	BOOL AddRecord();
	BOOL UpdateRecord();
	BOOL DeleteRecord();
	BOOL SelectMatchingRecords(const CString& sWhereClause);
	BOOL NextMatchingRecord();
	int CountMatchingRecords(const CString& sWhereClause);
	CString Quote(const CString& sText);

public:
	BOOL m_bOpen;		// True database/table open
	BOOL m_bBrackets;	// True = auto brackets around field names
	int m_nError;		// SQL completion code of last operation
	CString m_sQuery;	// Last query executed
	CString m_sErrMsg;	// Error message(s) from last operation
	CString m_sDSN;		// DSN name open
	CString m_sTable;	// Table name open

public:
	int m_nFields;
	CString m_sFieldName[MAX_FIELDS];
	CString m_sFieldValue[MAX_FIELDS];
	BOOL m_bKeyField[MAX_FIELDS];
	BOOL m_bNumeric[MAX_FIELDS];

private:
	RETCODE rc;
	HSTMT hstmt, hstmt_select;
	unsigned char szDSN[200];		// = "Activity"
	unsigned char szID[200];		// = "sa"
	unsigned char szPassword[200];	// = ""
	unsigned char szQuery[1024];
	unsigned char szTemp[1000];
	CString sTemp, sQuery1, sQuery2, sMsg;
	HENV henv;
	HDBC hdbc;
};
