// PWSAPI3Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "PWSAPI3.h"
#include "PWSAPI3Dlg.h"
#include "WxAPI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()





// CPWSAPI3Dlg dialog

CPWSAPI3Dlg::CPWSAPI3Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPWSAPI3Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPWSAPI3Dlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_LIST1, m_status_ctl);
    DDX_Control(pDX, IDOK, m_StartButton_ctl);
}

BEGIN_MESSAGE_MAP(CPWSAPI3Dlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
    ON_LBN_SELCHANGE(IDC_LIST1, &CPWSAPI3Dlg::OnLbnSelchangeList1)
    ON_BN_CLICKED(IDOK, &CPWSAPI3Dlg::OnBnClickedOk)
    ON_WM_TIMER()
END_MESSAGE_MAP()


// CPWSAPI3Dlg message handlers

BOOL CPWSAPI3Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon


	m_nButtonStatus=0;  //Initially we are not running.

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPWSAPI3Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPWSAPI3Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPWSAPI3Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CPWSAPI3Dlg::OnLbnSelchangeList1()
{
    // TODO: Add your control notification handler code here
}


//I will set this timer up to fire off every second and this will POST the data to the web site.
void CPWSAPI3Dlg::OnTimer(UINT nIDEvent)
{
   int  theResult;
   unsigned char theData[500];

   //My TEST variables!!!
	int	  mynStationNum=3211;

	CTime curTime = CTime::GetCurrentTime();

	int myHour=curTime.GetHour();
	int myMinute=curTime.GetMinute();
    int mySecond=curTime.GetSecond();
    int myDay=curTime.GetDay();
    int myMonth=curTime.GetMonth();
    int myYear=curTime.GetYear()-2000;

	float myindoortemp=73.5;  
	float myoutdoortemp=73.2;  //Outside Temperature in degrees F. -50 to 150: 0.01 precision
	float mygroundtemp=73.1;  //Ground/other Temperature in degrees F. -50 to 150: 0.01 precision
    float myhumidity=50.3;  //Relative Humidity 0 to 100%: 0.01 precision
	float mypressure=30.21;  //Barometric Pressure ("Hg) -28.00 to 32.00: 0.01 precision
	float mysolar=50.56;  //Solar Reading 0 to 1800 W/m2: 0.1 precision
	float myrain=2.13;  //Rainfall 0.00 to 100.00 inches: 0.01 precision
	float myWindSpeed=22.1;  //Wind Speed 0 to 200.00 miles per hour: 0.01 precision
	float myWindDir=100;  //Wind Direction 0 to 359.00 degrees: 0.01 precision
   	float myRainRate=0.60;  //Rain Rate 0 to 20.00 inches per hour: 0.01 precision
	float myAvgWindSpeed=20.1;  //Average Wind Speed in last 2 minutes: 0 to 200.00 miles per hour: 0.01 precision
	float myAvgWindDir=45.5;  //Average 2 minute Wind Direction 0 to 359.00 degrees: 0.01 precision
	float myOutTempRate=0;  //Outdoor Temperature Rate (deg F/hr): 0.01 precision
   	float myPressureRate=0;  //Pressure Rate (in Hg/hr): 0.01 precision
   	float myRHRate=0;  //Relative Humidity Rate (%/hr): 0.01 precision
   	float mySolarRate=0;  //Solar Rate (W/m2/hr): 0.01 precision
   	float mySoilMoisture=10;  //Soil Moisture %
   	float myLeafWetness=20;  //Leaf Wetness %
   	float myUV=55;  //UV .
   	float myVisibility=10;  //Visibility nm.

   	float myLastHourGust=30.33;  //Wind Gust in past hour (mph): 0-200 0.01 precision
   	float myLastHourGustDir=49.08;  //Direction of Wind Gust in past hour (mph): 0-359 0.01 precision
    char myHourGustTimeHr=11;  //The hour value of the hourly gust
	char myHourGustTimeMinute=11; //The minute value of the hourly gust.

	char myHiloMonth=curTime.GetMonth();   //This is the Month of the current high/low values 1-12
	char myHiloDay=curTime.GetDay();  //The current day of the high/low values 1-31
	int myHiloYear=curTime.GetYear(); 
   	float myHiOutTemp=90.33;  //Current High outdoor Temp Degrees F. -50 to 150, precision 0.01
    char myHiOutTempHour=17;  //Time of occurrance (Hour) of the outdoor temp high.
	char myHiOutTempMinute=33; //Time of occurrance (Minute) of the outdoor temp high. 
   	float myLoOutTemp=33.33;  //Current Low outdoor Temp Degrees F. -50 to 150, precision 0.01
	char myLoOutTempHour=6;
	char myLoOutTempMinute=23;
   	float myHiGroundTemp=56.55;  //Current High Ground Temp Degrees F. -50 to 150, precision 0.01
    char myHiGroundTempHour=11;  //Time of occurrance (Hour) of the Ground temp high.
	char myHiGroundTempMinute=11; //Time of occurrance (Minute) of the Ground temp high. 
   	float myLoGroundTemp=55.55;  //Current Low Ground Temp Degrees F. -50 to 150, precision 0.01
	char myLoGroundTempHour=20;  //Time of occurrance (Hour) of the Ground temp low.
	char myLoGroundTempMinute=11; //Time of occurrance (Minute) of the Ground temp low. 
   	float myHighHumidity=100.0;  //Current High Humidity %. 0 to 100, precision 0.01
    char myHiHumidityHour=11;  //Time of occurrance (Hour) of the high Humidity.
	char myHiHumidityMinute=11; //Time of occurrance (Minute) of the the high Humidity. 
   	float myLowHumidity=23;  //Current Low Humidity %. 0 to 100, precision 0.01
	char myLoHumidityHour=11;  //Time of occurrance (Hour) of the low humidity.
	char myLoHumidityMinute=11; //Time of occurrance (Minute) of the low humidity. 
   	float myHighPressure=30.33;  //Current High Barometer "Hg. 28 to 32, precision 0.01
    char myHiPressureHour=11;  //Time of occurrance (Hour) of the high Pressure.
	char myHiPressureMinute=11; //Time of occurrance (Minute) of the the high Pressure. 
   	float myLowPressure=28.77;  //Current Low Pressure "Hg. 28 to 32, precision 0.01
	char myLoPressureHour=11;  //Time of occurrance (Hour) of the low Pressure.
	char myLoPressureMinute=11; //Time of occurrance (Minute) of the low Pressure. 
   	float myGust=30.44;  //Current Wind Gust for the day. MPH 0 to 200, precision 0.01
    char myGustHour=11;  //Time of occurrance (Hour) of the Gust.
	char myGustMinute=11; //Time of occurrance (Minute) of the the Gust. 
   	float myGustDir=234;  //Direction of the wind gust. 0-359 precision 0.01
   	float myMaxRainRate=2.14;  //Current Max Rain rate for the day. inches 0 to 100 , precision 0.01
	char myMaxRainRateHour=11;
	char myMaxRainRateMinute=11;
	float myHighSolar=99.3;  //Current High Solar reading W/m2 0 to 1800, precision 0.01
    char myHighSolarHour=12;  //Time of occurrance (Hour) of the high Pressure.
	char myHighSolarMinute=12; //Time of occurrance (Minute) of the the high Pressure. 
   	float myLowSolar=0;  //Current Low olar reading W/m2 0 to 1800, precision 0.01
	char myLowSolarHour=23;  //Time of occurrance (Hour) of the low Solar.
	char myLowSolarMinute=59; //Time of occurrance (Minute) of the low Solar. 
	float myMonthlyRain=4.17;  //Rain so far this month 0.00 to 500.00 inches: 0.01 precision
	float myYearlyRain=20.73;  //Rain so far this year 0.00 to 500.00 inches: 0.01 precision

	//Set the values in the WxAPI!!!
	WxAPI	myWxAPI;

	//******THESE ARE THE KEY ELEMENTS NEEDED FROM THE USER REGISTRATION at http://reg.backyard2.weatherbug.com/reg/PwsRegPage.aspx
	myWxAPI.SetStationParameters(mynStationNum, "p00852", "weatherbug");

    myWxAPI.Hour=myHour;
    myWxAPI.Minute=myMinute;
    myWxAPI.Second=mySecond;
    myWxAPI.Day=myDay;
    myWxAPI.Month=myMonth;
    myWxAPI.Year=myYear;
	myWxAPI.indoortemp=myindoortemp;  //Inside Temperature in degrees F. -50 to 150: 0.01 precision
	myWxAPI.outdoortemp=myoutdoortemp;  //Outside Temperature in degrees F. -50 to 150: 0.01 precision
	myWxAPI.groundtemp=mygroundtemp;  //Ground/other Temperature in degrees F. -50 to 150: 0.01 precision
    myWxAPI.humidity=myhumidity;  //Relative Humidity 0 to 100%: 0.01 precision
	myWxAPI.pressure=mypressure;  //Barometric Pressure ("Hg) -28.00 to 32.00: 0.01 precision
	myWxAPI.solar=mysolar;  //Solar Reading 0 to 1800 W/m2: 0.1 precision
	myWxAPI.rain=myrain;  //Rainfall 0.00 to 100.00 inches: 0.01 precision
	myWxAPI.WindSpeed=myWindSpeed;  //Wind Speed 0 to 200.00 miles per hour: 0.01 precision
	myWxAPI.WindDir=myWindDir;  //Wind Direction 0 to 359.00 degrees: 0.01 precision
   	myWxAPI.RainRate=myRainRate;  //Rain Rate 0 to 20.00 inches per hour: 0.01 precision
	myWxAPI.AvgWindSpeed=myAvgWindSpeed;  //Average Wind Speed in last 2 minutes: 0 to 200.00 miles per hour: 0.01 precision
	myWxAPI.AvgWindDir=myAvgWindDir;  //Average 2 minute Wind Direction 0 to 359.00 degrees: 0.01 precision
	myWxAPI.OutTempRate=myOutTempRate;  //Outdoor Temperature Rate (deg F/hr): 0.01 precision
   	myWxAPI.PressureRate=myPressureRate;  //Pressure Rate (in Hg/hr): 0.01 precision
   	myWxAPI.RHRate=myRHRate;  //Relative Humidity Rate (%/hr): 0.01 precision
   	myWxAPI.SolarRate=mySolarRate;  //Solar Rate (W/m2/hr): 0.01 precision
   	myWxAPI.SoilMoisture=mySoilMoisture;  //Soil Moisture %
   	myWxAPI.LeafWetness=myLeafWetness;  //Leaf Wetness %
   	myWxAPI.UV=myUV;  //UV .
   	myWxAPI.Visibility=myVisibility;  //Visibility nm.

   	myWxAPI.LastHourGust=myLastHourGust;  //Wind Gust in past hour (mph): 0-200 0.01 precision
   	myWxAPI.LastHourGustDir=myLastHourGustDir;  //Direction of Wind Gust in past hour (mph): 0-359 0.01 precision
    myWxAPI.HourGustTimeHr=myHourGustTimeHr;  //The hour value of the hourly gust
	myWxAPI.HourGustTimeMinute=myHourGustTimeMinute; //The minute value of the hourly gust.

    myWxAPI.HiloMonth=myHiloMonth;   //This is the Month of the current high/low values 1-12
	myWxAPI.HiloDay=myHiloDay;  //The current day of the high/low values 1-31
	myWxAPI.HiloYear=myHiloYear; 
   	myWxAPI.HiOutTemp=myHiOutTemp;  //Current High outdoor Temp Degrees F. -50 to 150, precision 0.01
    myWxAPI.HiOutTempHour=myHiOutTempHour;  //Time of occurrance (Hour) of the outdoor temp high.
	myWxAPI.HiOutTempMinute=myHiOutTempMinute; //Time of occurrance (Minute) of the outdoor temp high. 
   	myWxAPI.LoOutTemp=myLoOutTemp;  //Current Low outdoor Temp Degrees F. -50 to 150, precision 0.01
	myWxAPI.LoOutTempHour=myLoOutTempHour;
	myWxAPI.LoOutTempMinute=myLoOutTempMinute;
   	myWxAPI.HiGroundTemp=myHiGroundTemp;  //Current High Ground Temp Degrees F. -50 to 150, precision 0.01
    myWxAPI.HiGroundTempHour=myHiGroundTempHour;  //Time of occurrance (Hour) of the Ground temp high.
	myWxAPI.HiGroundTempMinute=myHiGroundTempMinute; //Time of occurrance (Minute) of the Ground temp high. 
   	myWxAPI.LoGroundTemp=myLoGroundTemp;  //Current Low Ground Temp Degrees F. -50 to 150, precision 0.01
	myWxAPI.LoGroundTempHour=myLoGroundTempHour;  //Time of occurrance (Hour) of the Ground temp low.
	myWxAPI.LoGroundTempMinute=myLoGroundTempMinute; //Time of occurrance (Minute) of the Ground temp low. 
   	myWxAPI.HighHumidity=myHighHumidity;  //Current High Humidity %. 0 to 100, precision 0.01
    myWxAPI.HiHumidityHour=myHiHumidityHour;  //Time of occurrance (Hour) of the high Humidity.
	myWxAPI.HiHumidityMinute=myHiHumidityMinute; //Time of occurrance (Minute) of the the high Humidity. 
   	myWxAPI.LowHumidity=myLowHumidity;  //Current Low Humidity %. 0 to 100, precision 0.01
	myWxAPI.LoHumidityHour=myLoHumidityHour;  //Time of occurrance (Hour) of the low humidity.
	myWxAPI.LoHumidityMinute=myLoHumidityMinute; //Time of occurrance (Minute) of the low humidity. 
   	myWxAPI.HighPressure=myHighPressure;  //Current High Barometer "Hg. 28 to 32, precision 0.01
    myWxAPI.HiPressureHour=myHiPressureHour;  //Time of occurrance (Hour) of the high Pressure.
	myWxAPI.HiPressureMinute=myHiPressureMinute; //Time of occurrance (Minute) of the the high Pressure. 
   	myWxAPI.LowPressure=myLowPressure;  //Current Low Pressure "Hg. 28 to 32, precision 0.01
	myWxAPI.LoPressureHour=myLoPressureHour;  //Time of occurrance (Hour) of the low Pressure.
	myWxAPI.LoPressureMinute=myLoPressureMinute; //Time of occurrance (Minute) of the low Pressure. 
   	myWxAPI.Gust=myGust;  //Current Wind Gust for the day. MPH 0 to 200, precision 0.01
    myWxAPI.GustHour=myGustHour;  //Time of occurrance (Hour) of the Gust.
	myWxAPI.GustMinute=myGustMinute; //Time of occurrance (Minute) of the the Gust. 
   	myWxAPI.GustDir=myGustDir;  //Direction of the wind gust. 0-359 precision 0.01
   	myWxAPI.MaxRainRate=myMaxRainRate;  //Current Max Rain rate for the day. inches 0 to 100 , precision 0.01
	myWxAPI.MaxRainRateHour=myMaxRainRateHour;
	myWxAPI.MaxRainRateMinute=myMaxRainRateMinute;
	myWxAPI.HighSolar=myHighSolar;  //Current High Solar reading W/m2 0 to 1800, precision 0.01
    myWxAPI.HighSolarHour=myHighSolarHour;  //Time of occurrance (Hour) of the high Pressure.
	myWxAPI.HighSolarMinute=myHighSolarMinute; //Time of occurrance (Minute) of the the high Pressure. 
   	myWxAPI.LowSolar=myLowSolar;  //Current Low olar reading W/m2 0 to 1800, precision 0.01
	myWxAPI.LowSolarHour=myLowSolarHour;  //Time of occurrance (Hour) of the low Solar.
	myWxAPI.LowSolarMinute=myLowSolarMinute; //Time of occurrance (Minute) of the low Solar. 
	myWxAPI.MonthlyRain=myMonthlyRain;  //Rain so far this month 0.00 to 500.00 inches: 0.01 precision
	myWxAPI.YearlyRain=myYearlyRain;  //Rain so far this year 0.00 to 500.00 inches: 0.01 precision

	theResult=myWxAPI.TestPackandUnpack(); 

   //This is where I will do most of the work.
   CString sStatusString;
   sStatusString = "Working...";
   m_status_ctl.AddString((LPCTSTR)sStatusString);



   CString theResponse;
   CString theErrorMsg;

   theResponse = myWxAPI.PostLiveWeatherData();

   m_status_ctl.AddString((LPCTSTR)theResponse);
   //m_status_ctl.AddString((LPCTSTR)theErrorMsg);

   //SetTimer(1,1000,NULL);
}

void CPWSAPI3Dlg::OnBnClickedOk()
{
    // TODO: Add your control notification handler code here
    //This will start the application sending data!
	// **CDS This is where I will initialize timers and read from the INI file where to POST data to.
	if (m_nButtonStatus==0) {
		m_nButtonStatus=1;
		SetTimer(1, 1000, NULL);
		m_StartButton_ctl.SetWindowText(_T("Stop"));
		
	} else {
		m_nButtonStatus=0;
		m_StartButton_ctl.SetWindowText(_T("Start"));
		KillTimer(1);
	}
}
